import java.sql.*;
public class jdbc_app {
  public static void main(String args[]) throws Exception
  {
    System.out.println("jsdjhsa");
    Class.forName("org.postgresql.Driver");
    Connection cn=DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","1234"); 
    Statement st=cn.createStatement();
    ResultSet tb=st.executeQuery("select rollno from table1");
    while(tb.next())
    {
        System.out.println(tb.getString("rollno"));
    }
    cn.close();
 }
}
